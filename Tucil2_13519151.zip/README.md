# TUGAS KECIL 2 IF2211

# Catatan
Program ini belum sempurna, masih belum memberikan solusi yang tepat jika matkul memiliki lebih dari satu prasyarat.

# Penjelasan Program
Program ini merupakan program untuk melakukan pengurutan dalam menentukan mata kuliah yang harus diambil terlebih dahulu menggunakan topological sort yang mengimplementasikan algoritma decrease and conquer.

# Requirement
Program ini menggunakan bahasa java sehingga Anda memerlukan compiler java.

# Cara Menggunakan Program
Program ini hanya membaca file input.txt sehingga jika ingin mencoba test case yang lain Anda harus mengubah isi file input.txt menjadi kasus yang Anda inginkan. Jika menggunakan netbeans maka open projects dan pilih project program ini di folder src.

# Author
Azmi M. Syazwana || 13519151
